using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HybridInheritance2
{
    public class IDInfo:PersonalInfo
    {
        public static int s_VoterID=2000;
        
    }
}