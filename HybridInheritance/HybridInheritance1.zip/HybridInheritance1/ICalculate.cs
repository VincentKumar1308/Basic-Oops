using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HybridInheritance1
{
    public interface ICalculate
    {
        int ProjectMark{get;set;}
        void Total();
        
    }
}